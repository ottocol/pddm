# Cómo montar la plantilla del restaurante en Xcode 15

Estos son solo los archivos fuente. El proyecto de Xcode hay que crearlo en el Mac (unos 5 minutos):

1. **Crear el proyecto**: en Xcode 15, `File > New > Project... > iOS > App`.
    - Product Name: `Restaurante` (el nombre importa: el `PersistenceController` busca el modelo `Restaurante`)
    - Interface: `SwiftUI`
    - Language: `Swift`
    - Storage: `Core Data`, sin marcar `Host in CloudKit`
    - Desmarcar `Include Tests`

2. **Vaciar el modelo de datos**: abrir `Restaurante.xcdatamodeld`, seleccionar la entidad `Item` y borrarla. El modelo debe quedar **vacío**, ya que lo crean los alumnos en el primer apartado.

3. **Sustituir el código generado**: borrar del proyecto (`Move to Trash`) los archivos `ContentView.swift`, `RestauranteApp.swift` y `Persistence.swift` que ha generado Xcode.

4. **Añadir los fuentes de la plantilla**: arrastrar al navegador del proyecto, dentro de la carpeta `Restaurante`, todo el contenido de la carpeta `Restaurante` de este paquete: los tres `.swift` sueltos, las carpetas `Carta`, `Pedido`, `Historial` y `Util`, y `platos.json`. En el diálogo, marcar `Copy items if needed`, `Create groups` y el *target* `Restaurante`.

5. **Comprobar**:
    - Que `platos.json` aparece en el *target*, en `Build Phases > Copy Bundle Resources`.
    - Que el proyecto compila sin errores y, al ejecutarlo, aparecen las tres pestañas con los datos de ejemplo.
    - Que en la consola aparece `Importando platos...` e `Importados 20 platos`. Es normal que aparezca en cada ejecución: la línea que marca los platos como importados está comentada hasta que los alumnos implementen la importación.

6. **Empaquetar**: `Product > Clean Build Folder`, cerrar Xcode y, desde la carpeta que contiene el proyecto:

    ```bash
    zip -r plantilla_restaurante.zip Restaurante -x "*/xcuserdata/*" "*.DS_Store"
    ```

El diagrama del modelo de datos (`modelo_datos.png`) sigue sirviendo tal cual. El diagrama UML de clases de la versión UIKit ya no corresponde a la plantilla; el enunciado incluye en su lugar una tabla con los archivos.
