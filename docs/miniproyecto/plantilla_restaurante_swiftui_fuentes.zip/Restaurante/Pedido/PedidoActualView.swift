import SwiftUI
import CoreData

@MainActor
struct PedidoActualView: View {
    //TODO: declarar aquí la consulta del pedido actual (el Pedido sin fecha)

    //mensaje que se muestra al realizar o cancelar un pedido
    @State private var mensaje = ""

    var body: some View {
        NavigationStack {
            Group {
                //TODO: si hay pedido actual, mostrar un FormularioPedido con ese pedido.
                //Si no lo hay, mostrar la vista "pedidoVacio" (definida más abajo)
                FormularioPedido(mensaje: $mensaje)
            }
            .navigationTitle("Tu pedido")
        }
    }

    //lo que se muestra cuando no hay pedido actual
    var pedidoVacio: some View {
        ContentUnavailableView("Tu pedido está vacío",
                               systemImage: "cart",
                               description: Text(mensaje.isEmpty ? "Añade platos desde la carta" : mensaje))
    }
}

#Preview {
    PedidoActualView()
        .environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
}
