import SwiftUI

//Una fila del pedido actual: el nombre del plato y la cantidad, con un Stepper para cambiarla
struct FilaLinea: View {
    let nombre: String
    let cantidad: Int
    //acción que se ejecuta cuando el usuario cambia la cantidad con el Stepper
    let alCambiarCantidad: (Int) -> Void

    var body: some View {
        Stepper(value: Binding(get: { cantidad }, set: { alCambiarCantidad($0) }),
                in: 1...100) {
            HStack {
                Text(nombre)
                Spacer()
                Text("\(cantidad)")
                    .monospacedDigit()
                    .foregroundStyle(.secondary)
            }
        }
    }
}

#Preview {
    List {
        FilaLinea(nombre: "Pizza margarita", cantidad: 2) { nuevaCantidad in
            print("Nueva cantidad: \(nuevaCantidad)")
        }
    }
}
