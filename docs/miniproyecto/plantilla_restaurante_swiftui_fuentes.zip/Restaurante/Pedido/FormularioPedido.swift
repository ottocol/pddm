import SwiftUI
import CoreData

//Muestra las líneas de un pedido, el total y los datos de entrega,
//y permite realizar o cancelar el pedido
@MainActor
struct FormularioPedido: View {
    @Environment(\.managedObjectContext) private var contexto

    //TODO: añadir una propiedad con el pedido que se muestra y,
    //en un inicializador, crear la consulta de sus líneas

    //el mensaje se guarda en la vista padre (PedidoActualView), que lo mostrará
    //cuando ya no haya pedido actual. @Binding permite modificar una variable
    //que pertenece a otra vista
    @Binding var mensaje: String

    @State private var direccion = ""
    @State private var telefono = ""

    //el importe total del pedido
    var total: Double {
        //TODO: calcular el total
        return 0
    }

    var body: some View {
        Form {
            Section("Platos") {
                //TODO: una FilaLinea por cada línea del pedido.
                //Esta fila de ejemplo es solo para que veas el aspecto que tendrá: bórrala
                FilaLinea(nombre: "Plato de ejemplo", cantidad: 1) { nuevaCantidad in
                    print("Nueva cantidad: \(nuevaCantidad)")
                }
            }

            Section {
                HStack {
                    Text("Total")
                    Spacer()
                    Text(total.formatted(.currency(code: "EUR")))
                        .bold()
                }
            }

            Section("Entrega") {
                TextField("Dirección", text: $direccion)
                TextField("Teléfono", text: $telefono)
                    .keyboardType(.phonePad)
            }

            Section {
                Button("Realizar pedido") {
                    realizarPedido()
                }
                .disabled(direccion.isEmpty || telefono.isEmpty)

                Button("Cancelar pedido", role: .destructive) {
                    cancelarPedido()
                }
            }
        }
    }

    func realizarPedido() {
        //TODO: realizar el pedido
        mensaje = "¡Tu pedido está en camino!"
    }

    func cancelarPedido() {
        //TODO: cancelar el pedido
        mensaje = "Pedido cancelado"
    }
}

#Preview {
    FormularioPedido(mensaje: .constant(""))
        .environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
}
