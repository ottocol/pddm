import Foundation
import CoreData

//Los datos de un plato tal como vienen en el JSON
struct DatosPlato: Codable {
    let nombre: String
    let descripcion: String
    let precio: Double
    let tipo: String
}

enum ImportadorPlatos {

    //Lee los platos del archivo platos.json incluido en la app
    static func leerJSON() throws -> [DatosPlato] {
        guard let url = Bundle.main.url(forResource: "platos", withExtension: "json") else {
            throw CocoaError(.fileNoSuchFile)
        }
        let datos = try Data(contentsOf: url)
        return try JSONDecoder().decode([DatosPlato].self, from: datos)
    }

    //Importa los platos en Core Data, solo si no se han importado antes.
    //Se llama al arrancar la app (ver RestauranteApp.swift)
    static func importarSiHaceFalta() async {
        let prefs = UserDefaults.standard
        if prefs.bool(forKey: "platosImportados") {
            return
        }
        print("Importando platos...")
        do {
            let platos = try leerJSON()
            //TODO: copiar los datos del array "platos" a entidades Plato de Core Data,
            //en un contexto en segundo plano, y guardar el contexto

            print("Importados \(platos.count) platos")
            //TODO: descomenta la siguiente línea cuando hayas implementado la importación.
            //Indica que los platos ya se han importado, para no volver a hacerlo
            //prefs.set(true, forKey: "platosImportados")
        } catch {
            print("Error al importar los platos: \(error)")
        }
    }
}
