import SwiftUI
import CoreData

@MainActor
struct CartaView: View {
    @Environment(\.managedObjectContext) private var contexto

    //TODO: declarar aquí la consulta de los platos, agrupados en secciones por tipo

    @State private var textoBusqueda = ""

    var body: some View {
        NavigationStack {
            List {
                //TODO: una sección por cada tipo de plato, con una FilaPlato por cada plato.
                //Esta sección de ejemplo es solo para que veas el aspecto que tendrá: bórrala
                Section("Ejemplo") {
                    FilaPlato(nombre: "Pizza de ejemplo",
                              descripcion: "Bórrame cuando muestres los platos de verdad",
                              precio: 9.95) {
                        print("Añadir pulsado")
                    }
                }
            }
            .navigationTitle("Carta")
            .searchable(text: $textoBusqueda, prompt: "Buscar platos")
            //TODO: filtrar los platos según el texto de búsqueda
        }
    }

    //TODO: añadir el plato al pedido actual
}

#Preview {
    CartaView()
        .environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
}
