import SwiftUI

//Una fila de la carta, con los datos de un plato y el botón "Añadir"
struct FilaPlato: View {
    let nombre: String
    let descripcion: String
    let precio: Double
    //acción que se ejecuta al pulsar el botón "Añadir"
    let alAñadir: () -> Void

    var body: some View {
        HStack(alignment: .top) {
            VStack(alignment: .leading, spacing: 4) {
                Text(nombre)
                    .font(.headline)
                Text(descripcion)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                Text(precio.formatted(.currency(code: "EUR")))
                    .font(.subheadline.bold())
            }
            Spacer()
            Button("Añadir", action: alAñadir)
                .buttonStyle(.bordered)
        }
        .padding(.vertical, 4)
    }
}

#Preview {
    List {
        FilaPlato(nombre: "Pizza margarita",
                  descripcion: "Tomate, mozzarella y albahaca",
                  precio: 9.5) {
            print("Añadir")
        }
    }
}
