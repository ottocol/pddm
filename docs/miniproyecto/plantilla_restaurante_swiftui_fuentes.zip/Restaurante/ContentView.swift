import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            CartaView()
                .tabItem { Label("Carta", systemImage: "fork.knife") }
            PedidoActualView()
                .tabItem { Label("Tu pedido", systemImage: "cart") }
            HistorialView()
                .tabItem { Label("Historial", systemImage: "clock") }
        }
    }
}

#Preview {
    ContentView()
        .environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
}
