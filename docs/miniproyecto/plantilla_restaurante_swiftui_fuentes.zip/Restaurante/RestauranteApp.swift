import SwiftUI

@main
struct RestauranteApp: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
                .task {
                    //la primera vez que se ejecuta la app, importa los platos del JSON
                    await ImportadorPlatos.importarSiHaceFalta()
                }
        }
    }
}
