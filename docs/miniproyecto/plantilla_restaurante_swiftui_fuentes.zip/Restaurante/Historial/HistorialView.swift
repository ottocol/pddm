import SwiftUI
import CoreData

@MainActor
struct HistorialView: View {
    //TODO: declarar aquí la consulta de los pedidos realizados

    var body: some View {
        NavigationStack {
            List {
                //TODO: una fila por cada pedido realizado
                Text("Aquí aparecerán tus pedidos")
                    .foregroundStyle(.secondary)
            }
            .navigationTitle("Historial")
        }
    }
}

#Preview {
    HistorialView()
        .environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
}
